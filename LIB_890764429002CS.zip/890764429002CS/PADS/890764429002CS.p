*PADS-LIBRARY-PART-TYPES-V9*

890764429002CS 890764429002CS I CAP 7 1 0 0 0
TIMESTAMP 2026.09.29.08.13.26
"Mouser Part Number" 710-890764429002CS
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Wurth-Elektronik/890764429002CS?qs=rQFj71Wb1eWFHSpjNQ4CNg%3D%3D
"Manufacturer_Name" Wurth Elektronik
"Manufacturer_Part_Number" 890764429002CS
"Description" WCAP-FTDB DC-Link Capacitor (MKP) MDBP525606J600DCPP15040; THT Boxed; 60 F +/- 5%; 600 V(DC); Riso > 166.66 M; pitch 52.5; climate category 40/85/56
"Datasheet Link" https://www.we-online.com/catalog/datasheet/890764429002CS.pdf
"Geometry.Height" 43.5mm
GATE 1 4 0
890764429002CS
1 0 U 1
2 0 U 2
3 0 U 3
4 0 U 4

*END*
*REMARK* SamacSys ECAD Model
20059567/2175399/2.50/4/2/Capacitor
